# SavingMoneyUnina OOBD2324_16

## Informazioni generali

- Progetto di Basi di Dati,2023- 2024.
- Il Database è stato realizzato utilizzando PostgreSQL.
- I commenti al codice sono presenti nella documentazione e nei file sorgenti.
